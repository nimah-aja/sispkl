import React, { useEffect, useState } from "react";
import Add from "./components/Add";

// Import API
import { getIndustri } from "../utils/services/admin/get_industri";
import { submitPengajuanPKL } from "../utils/services/siswa/pengajuan_pkl";

export default function PengajuanPKL() {
  const [listIndustri, setListIndustri] = useState([]);

  // ambil data industri saat halaman dibuka
  useEffect(() => {
    const fetchIndustri = async () => {
      try {
        const data = await getIndustri();
        const formatted = data.map((item) => ({
          label: item.nama,
          value: item.id, // yang dikirim ke backend nanti ID!
        }));
        setListIndustri(formatted);
      } catch (error) {
        console.error("Gagal mengambil data industri:", error);
      }
    };

    fetchIndustri();
  }, []);

  // form dynamic Add.jsx
  const fields = [
    {
      name: "industri_id",
      label: "Nama Industri",
      type: "select",
      width: "full",
      options: listIndustri,
    },
    {
      name: "catatan",
      label: "Catatan",
      type: "textarea",
      width: "full",
      rows: 4,
    },
  ];

  const handleSubmit = async (formData) => {
    const payload = {
      industri_id: parseInt(formData.get("industri_id")), // backend minta INT!
      catatan: formData.get("catatan"),
    };

    console.log("DATA DIKIRIM:", payload);

    try {
      const res = await submitPengajuanPKL(payload);
      alert("Pengajuan berhasil dikirim!");
    } catch (error) {
      alert("Gagal mengirim pengajuan!");
    }
  };

  return (
    <Add
      title="Pengajuan PKL"
      fields={fields}
      onSubmit={handleSubmit}
      onCancel={() => window.history.back()}
      backgroundStyle={{ backgroundColor: "#F4EFE6" }}
    />
  );
}