import React, { useEffect, useState } from "react";
import dayjs from "dayjs";

export default function PKLProgressCircle({ startDate, endDate }) {
//   if (!startDate || !endDate) return null;

  const start = dayjs(startDate).startOf("day");
  const end = dayjs(endDate).startOf("day");
  const today = dayjs().startOf("day");

  const totalDays = end.diff(start, "day");

let passedDays = 0;
let remainingDays = totalDays;
let percentage = 0;

if (today.isBefore(start)) {
  // 🔹 PKL belum dimulai
  passedDays = 0;
  remainingDays = totalDays;
  percentage = 0;
} else if (today.isAfter(end)) {
  // 🔹 PKL sudah selesai
  passedDays = totalDays;
  remainingDays = 0;
  percentage = 100;
} else {
  // 🔹 PKL sedang berlangsung
  passedDays = today.diff(start, "day");
  remainingDays = end.diff(today, "day");
  percentage = Math.round((passedDays / totalDays) * 100);
}


  // 🔥 DONUT CONFIG (DIBESARIN)
  const radius = 78;          // ⬅️ makin gede
  const strokeWidth = 30;     // ⬅️ makin tebel
  const circumference = 2 * Math.PI * radius;

  const [animatedPercent, setAnimatedPercent] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => {
      setAnimatedPercent(percentage);
    }, 100);

    return () => clearTimeout(t);
  }, [percentage]);

  const progressOffset =
    circumference - (animatedPercent / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center bg-white border border-[#641E21]-200 rounded-2xl p-13 shadow-sm w-[450px]">
      <div className="relative w-[240px] h-[240px]">
        <svg
          className="w-full h-full -rotate-90"
          viewBox="0 0 200 200"
        >
          {/* BACKGROUND DONUT */}
          <circle
            cx="100"
            cy="100"
            r={radius}
            fill="transparent"
            stroke="#E5E7EB"
            strokeWidth={strokeWidth}
            strokeDasharray="6 8"
          />

          {/* PROGRESS DONUT */}
          <circle
            cx="100"
            cy="100"
            r={radius}
            fill="transparent"
            stroke="#EC933A"
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={progressOffset}
            strokeLinecap="round"
            style={{
              transition: "stroke-dashoffset 1.4s ease-out",
            }}
          />
        </svg>

        {/* CENTER TEXT */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="text-5xl font-bold text-gray-900">
            {animatedPercent}%
          </span>
          <span className="text-sm text-gray-700 mt-1">
            Sisa {remainingDays} hari
          </span>
        </div>
      </div>

      <p className="mt-4 text-xl font-bold text-gray-900">
        Progress PKL
      </p>
    </div>
  );
}
