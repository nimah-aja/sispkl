import React from "react";
import {
  FilePlus,
  ArrowLeftRight,
  CalendarX,
  CheckCircle,
} from "lucide-react";

export default function QuickActions({ onAction }) {
  const actions = [
    {
      label: "Pengajuan PKL",
      icon: <FilePlus size={28} className="text-blue-600" />,
      bg: "bg-blue-100",
      key: "pengajuan_pkl",
    },
    {
      label: "Pengajuan Pindah PKL",
      icon: <ArrowLeftRight size={28} className="text-green-600" />,
      bg: "bg-green-100",
      key: "pindah_pkl",
    },
    {
      label: "Izin PKL",
      icon: <CalendarX size={28} className="text-purple-600" />,
      bg: "bg-purple-100",
      key: "izin_pkl",
    },
    {
      label: "Kirim Bukti Diterima",
      icon: <CheckCircle size={28} className="text-orange-600" />,
      bg: "bg-orange-100",
      key: "bukti_diterima",
    },
  ];

  return (
    <div className="bg-white shadow-sm rounded-xl p-6 shadow-sm border border-[#6e0f0f]">
      <h2 className="font-semibold text-lg mb-4">Fitur Utama</h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 ">
        {actions.map((item) => (
          <div
            key={item.key}
            onClick={() => onAction?.(item.key)}
            className="cursor-pointer border border-[#6e0f0f] rounded-xl p-4 flex flex-col items-center justify-center hover:shadow-md transition"
          >
            <div className={`${item.bg} p-3 rounded-lg mb-2`}>
              {item.icon}
            </div>
            <p className="text-sm font-medium text-gray-700 text-center">
              {item.label}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
