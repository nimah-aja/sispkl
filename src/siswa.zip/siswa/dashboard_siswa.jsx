import React, { useEffect, useState } from "react";
import { Bell } from "lucide-react";

import Sidebar from "./components/Sidebar";
import KalenderPKL from "./components/Calender";
import StatusPengajuanPKL from "./components/notification";
import JadwalPKLCard from "./components/JadwalPKL";
import AktivitasTerkini from "./components/AktivitasTerkini";
import DashboardCard from "./components/DashboardCard";
import Header from "./components/Header";
import QuickActions from "./components/QuickAction";
import QuickActionsPager from "./components/dot";
import PKLProgressCircle from "./components/Progress";
import { getPengajuanMe } from "../utils/services/siswa/pengajuan_pkl";
import {getIndustri} from "../utils/services/admin/get_industri";
import {getGuru} from "../utils/services/admin/get_guru";




// ICONS
import userIcon from "../assets/sidebarUsers.svg";
import timeIcon from "../assets/timewalkel.png";

// axios instance
import axios from "../utils/axiosInstance";

// DAYJS
import dayjs from "dayjs";

export default function DashboardSiswa() {
  const [industriMap, setIndustriMap] = useState({});
  const [guruMap, setGuruMap] = useState({});
  const [aktivitas, setAktivitas] = useState([]);
  const [activePKLData, setActivePKLData] = useState(null);
  const [user] = useState(
    JSON.parse(localStorage.getItem("user")) || { name: "Guest", role: "Siswa" }
  );

  const [dashboardData, setDashboardData] = useState([
    { title: "Status PKL", value: "-", icon: userIcon },
    { title: "Sisa Hari PKL", value: "-", icon: timeIcon },
  ]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const dataDummy = [
    {
      type: "submit", // submit | approved | rejected
      title: "Mengajukan PKL",
      description: "Pengajuan PKL di UBIG",
      time: "2 jam yang lalu",
    },
    {
      type: "approved",
      title: "Diantebes Menyetujui Pengajuan",
      description: "Persetujuan PKL di UBIG",
      time: "2 jam yang lalu",
    },
    {
      type: "rejected",
      title: "Diantebes Menolak Pengajuan",
      description: "Pengajuan PKL di UBIG ditolak",
      time: "2 jam yang lalu",
    },
  ];

  useEffect(() => {
  const fetchIndustri = async () => {
    try {
      const res = await getIndustri();
      const map = {};
      res.forEach((i) => {
        map[i.id] = i.nama;
      });
      setIndustriMap(map);
    } catch (err) {
      console.error("Gagal ambil industri", err);
    }
  };

  fetchIndustri();
}, []);

useEffect(() => {
  const fetchGuru = async () => {
    try {
      const res = await getGuru();
      const map = {};
      res.forEach((g) => {
        map[g.id] = g.nama;
      });
      setGuruMap(map);
    } catch (err) {
      console.error("Gagal ambil guru", err);
    }
  };

  fetchGuru();
}, []);

useEffect(() => {
  if (
    Object.keys(industriMap).length === 0 ||
    Object.keys(guruMap).length === 0
  )
    return;

  const fetchPKL = async () => {
    try {
      const res = await getPengajuanMe();
      const list = res.data || [];

      const aktivitasList = [];

      list.forEach((item) => {
        const namaIndustri =
          industriMap[item.industri_id] || "Industri tidak diketahui";

        if (item.tanggal_permohonan) {
          aktivitasList.push({
            type: "submit",
            title: "Anda Mengajukan PKL",
            description: `Pengajuan PKL di ${namaIndustri}`,
            time: dayjs(item.tanggal_permohonan),
          });
        }

        if (item.decided_at) {
          const namaGuru =
            guruMap[item.processed_by] || "Kaprog";

          aktivitasList.push({
            type: item.status === "Approved" ? "approved" : "rejected",
            title:
              item.status === "Approved"
                ? `${namaGuru} telah menyetujui pengajuan anda`
                : `${namaGuru} telah menolak pengajuan anda`,
            description: `Pengajuan PKL di ${namaIndustri}`,
            time: dayjs(item.decided_at),
          });
        }
      });

      aktivitasList.sort((a, b) => b.time.valueOf() - a.time.valueOf());

      setAktivitas(
        aktivitasList.map((a) => ({
          ...a,
          time: a.time.format("DD MMM YYYY HH:mm"),
        }))
      );
    } catch (err) {
      console.error("Gagal mengambil aktivitas PKL", err);
    }
  };

  fetchPKL();
}, [industriMap, guruMap]);



  useEffect(() => {
    const fetchPKL = async () => {
      setLoading(true);
      setError("");

      try {
        const res = await axios.get("/api/pkl/applications/me");
        const data = res.data.data[0];
        setActivePKLData(data);

        if (data) {
          const today = dayjs().startOf("day");
          const endDate = dayjs(data.tanggal_selesai).startOf("day");

          const diffDays = endDate.diff(today, "day");

          setDashboardData([
            {
              title: "Status PKL",
              value: data.status === "Approved" ? "Aktif" : "Tidak Aktif",
              icon: userIcon,
            },
            {
              title: "Sisa Hari PKL",
              value: diffDays > 0 ? diffDays : 0,
              icon: timeIcon,
            },
          ]);
        } else {
          setDashboardData([
            { title: "Status PKL", value: "Tidak Aktif", icon: userIcon },
            { title: "Sisa Hari PKL", value: 0, icon: timeIcon },
          ]);
        }
      } catch (err) {
        console.error(err);
        setError("Gagal mengambil data PKL.");
        setDashboardData([
          { title: "Status PKL", value: "Tidak Aktif", icon: userIcon },
          { title: "Sisa Hari PKL", value: 0, icon: timeIcon },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchPKL();
  }, []);

  return (
    <div className="flex">
      <Sidebar />

      <div className="flex-1 p-6 bg-white min-h-screen">
        <div className="-mt-9 -ml-6"><Header user={user} notifications={aktivitas}/></div>

        {/* Dashboard Cards */}
        {/* <div className="mt-6">
          {loading ? (
            <p className="text-black font-semibold">Loading data...</p>
          ) : error ? (
            <p className="text-red-600 font-medium">{error}</p>
          ) : (
            <DashboardCard data={dashboardData} />
          )}
        </div> */}

        {/* Grid Status & Jadwal */}
        {/* Grid Status & Jadwal */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6 items-stretch">
          <div className="space-y-6">
            <StatusPengajuanPKL dataPKL={activePKLData} />
          </div>
          <div className="space-y-6">
            <JadwalPKLCard dataPKL={activePKLData} />
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-6">
          <QuickActions />
        </div>

        {/* Quick Actions – iPhone Style */}
        <div className="fixed bottom-6 -right-100 w-[320px] ">
          <QuickActionsPager />
        </div>



        {/* Kalender */}
        <div className="mt-6">
          <KalenderPKL pklData={activePKLData} />
        </div>


        {/* Aktivitas Terkini + Progress PKL */}
        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          
          {/* Aktivitas Terkini */}
          <div className="lg:col-span-2">
            <AktivitasTerkini
              title="Notifikasi"
              icon={<Bell size={22} />}
              items={aktivitas}

            />
          </div>

          {/* Progress PKL */}
          {activePKLData && (
            <div className="flex justify-center">
              <PKLProgressCircle
                startDate={activePKLData?.tanggal_mulai}
                endDate={activePKLData?.tanggal_selesai}
                status={activePKLData?.status}
              />

            </div>
          )}
        </div>




      </div>
    </div>
  );
}
